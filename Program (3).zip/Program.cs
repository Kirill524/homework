﻿//Задание 1
//Объявить одномерный (5 элементов) массив с именем A и двумерный массив (3 строки, 4 столбца) дробных чисел с именем B. Заполнить одномерный массив
//А числами, введенными с клавиатуры пользователем, а
//двумерный массив В случайными числами с помощью
//циклов. Вывести на экран значения массивов: массива
//А в одну строку, массива В — в виде матрицы. Найти в
//данных массивах общий максимальный элемент, минимальный элемент, общую сумму всех элементов, общее
//произведение всех элементов, сумму четных элементов
//массива А, сумму нечетных столбцов массива В.

using System;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        double[] A = new double[5];
        Console.WriteLine("Введите 5 чисел для массива A:");

        for (int i = 0; i < 5; i++)
        {
            Console.Write($"A[{i}] = ");
            A[i] = double.Parse(Console.ReadLine());
        }

        double[,] B = new double[3, 4];
        Random rnd = new Random();

        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 4; j++)
                B[i, j] = Math.Round(rnd.NextDouble() * 10, 2);

        Console.WriteLine("\nМассив A:");
        foreach (double x in A) Console.Write(x + " ");

        Console.WriteLine("\n\nМассив B:");
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 4; j++)
                Console.Write(B[i, j] + "\t");
            Console.WriteLine();
        }

        double max = A[0], min = A[0], sum = 0, prod = 1;

        foreach (double x in A)
        {
            if (x > max) max = x;
            if (x < min) min = x;
            sum += x;
            prod *= x;
        }

        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 4; j++)
            {
                double x = B[i, j];
                if (x > max) max = x;
                if (x < min) min = x;
                sum += x;
                prod *= x;
            }

        double evenSumA = 0;
        foreach (double x in A)
            if (x % 2 == 0) evenSumA += x;

        double oddColSumB = 0;
        for (int j = 1; j < 4; j += 2)
            for (int i = 0; i < 3; i++)
                oddColSumB += B[i, j];

        Console.WriteLine($"\nМаксимум: {max}");
        Console.WriteLine($"Минимум: {min}");
        Console.WriteLine($"Общая сумма: {sum}");
        Console.WriteLine($"Общее произведение: {prod}");
        Console.WriteLine($"Сумма четных элементов A: {evenSumA}");
        Console.WriteLine($"Сумма нечётных столбцов B: {oddColSumB}");
    }
}

//Задание 2
//Дан двумерный массив размерностью 5×5, заполненный случайными числами из диапазона от –100 до 100.
//Определить сумму элементов массива, расположенных
//между минимальным и максимальным элементами.

using System;

class Program
{
    static void Main()
    {
        int[,] arr = new int[5, 5];
        Random rnd = new Random();

        int min = int.MaxValue, max = int.MinValue;
        int minIndex = 0, maxIndex = 0;

        int[] flat = new int[25];
        int k = 0;

        for (int i = 0; i < 5; i++)
            for (int j = 0; j < 5; j++)
            {
                arr[i, j] = rnd.Next(-100, 101);
                flat[k] = arr[i, j];

                if (arr[i, j] < min) { min = arr[i, j]; minIndex = k; }
                if (arr[i, j] > max) { max = arr[i, j]; maxIndex = k; }

                k++;
            }

        Console.WriteLine("Матрица:");
        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 5; j++)
                Console.Write(arr[i, j] + "\t");
            Console.WriteLine();
        }

        int start = Math.Min(minIndex, maxIndex) + 1;
        int end = Math.Max(minIndex, maxIndex);

        int sum = 0;
        for (int i = start; i < end; i++)
            sum += flat[i];

        Console.WriteLine($"\nMin = {min}, Max = {max}");
        Console.WriteLine($"Сумма между ними = {sum}");
    }
}

//Задание 3
//Пользователь вводит строку с клавиатуры. Необходимо зашифровать данную строку используя шифр Цезаря.
//Из Википедии:Шифр Цезаря — это вид шифра подстановки, в котором каждый символ в открытом тексте заменяется
//символом, находящимся на некотором постоянном числе
//позиций левее или правее него в алфавите. Например,
//в шифре со сдвигом вправо на 3, A была бы заменена на
//D, B станет E, и так далее.
//Подробнее тут: https://en.wikipedia.org/wiki/Caesar_
//cipher.
//Кроме механизма шифровки, реализуйте механизм

using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите строку: ");
        string s = Console.ReadLine();

        Console.Write("Введите сдвиг: ");
        int shift = int.Parse(Console.ReadLine());

        string encrypted = Caesar(s, shift);
        string decrypted = Caesar(encrypted, -shift);

        Console.WriteLine("\nЗашифровано: " + encrypted);
        Console.WriteLine("Расшифровано: " + decrypted);
    }

    static string Caesar(string text, int shift)
    {
        string result = "";

        foreach (char c in text)
        {
            if (char.IsLetter(c))
            {
                char a = char.IsUpper(c) ? 'A' : 'a';
                result += (char)(a + (c - a + shift + 26) % 26);
            }
            else result += c;
        }

        return result;
    }
}

//расшифрования.Задание 4
//Создайте приложение, которое производит операции
//над матрицами:
//■ Умножение матрицы на число;
//■ Сложение матриц;
//■ Произведение матриц.

using System;

class Program
{
    static void Main()
    {
        int[,] A = { { 1, 2 }, { 3, 4 } };
        int[,] B = { { 5, 6 }, { 7, 8 } };

        Console.WriteLine("A × 3:");
        PrintMatrix(MulNumber(A, 3));

        Console.WriteLine("A + B:");
        PrintMatrix(Add(A, B));

        Console.WriteLine("A × B:");
        PrintMatrix(Mul(A, B));
    }

    static int[,] MulNumber(int[,] A, int n)
    {
        int rows = A.GetLength(0);
        int cols = A.GetLength(1);
        int[,] R = new int[rows, cols];

        for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols; j++)
                R[i, j] = A[i, j] * n;

        return R;
    }

    static int[,] Add(int[,] A, int[,] B)
    {
        int rows = A.GetLength(0);
        int cols = A.GetLength(1);
        int[,] R = new int[rows, cols];

        for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols; j++)
                R[i, j] = A[i, j] + B[i, j];

        return R;
    }

    static int[,] Mul(int[,] A, int[,] B)
    {
        int rows = A.GetLength(0);
        int cols = B.GetLength(1);
        int mid = A.GetLength(1);

        int[,] R = new int[rows, cols];

        for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols; j++)
                for (int k = 0; k < mid; k++)
                    R[i, j] += A[i, k] * B[k, j];

        return R;
    }

    static void PrintMatrix(int[,] M)
    {
        for (int i = 0; i < M.GetLength(0); i++)
        {
            for (int j = 0; j < M.GetLength(1); j++)
                Console.Write(M[i, j] + "\t");
            Console.WriteLine();
        }
        Console.WriteLine();
    }
}

//Задание 5
//Пользователь с клавиатуры вводит в строку арифметическое выражение. Приложение должно посчитать
//его результат. Необходимо поддерживать только две
//операции: +и –.

using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите выражение (например: 10 + 5 - 2): ");
        string expr = Console.ReadLine();

        string[] parts = expr.Split(' ');
        int result = int.Parse(parts[0]);

        for (int i = 1; i < parts.Length; i += 2)
        {
            string op = parts[i];
            int num = int.Parse(parts[i + 1]);

            if (op == "+") result += num;
            else if (op == "-") result -= num;
        }

        Console.WriteLine("Результат: " + result);
    }
}

//Задание 6
//Пользователь с клавиатуры вводит некоторый текст.
//Приложение должно изменять регистр первой буквы
//каждого предложения на букву в верхнем регистре.Например, если пользователь ввёл: «today is a good
//day for walking. i will try to walk near the sea».
//Результат работы приложения: «Today is a good day
//for walking. I will try to walk near the sea».

using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите текст: ");
        string s = Console.ReadLine();

        string[] sentences = s.Split(new char[] { '.', '?', '!' },
            StringSplitOptions.RemoveEmptyEntries);

        string result = "";

        foreach (string sent in sentences)
        {
            string t = sent.Trim();
            if (t.Length > 0)
                result += char.ToUpper(t[0]) + t.Substring(1) + ". ";
        }

        Console.WriteLine("\n" + result);
    }
}

//Задание 7
//Создайте приложение, проверяющее текст на недопустимые слова. Если недопустимое слово найдено, оно
//должно быть заменено на набор символов *. По итогам
//работы приложения необходимо показать статистику
//действий.
//Например, если и у нас есть такой текст:
//To be, or not to be, that is the question,
//Whether 'tis nobler in the mind to suffer
//The slings and arrows of outrageous fortune,
//Or to take arms against a sea of troubles,
//And by opposing end them? To die: to sleep;
//No more; and by a sleep to say we end
//The heart-ache and the thousand natural shocks
//That flesh is heir to, 'tis a consummation
//Devoutly to be wish'd. To die, to sleep
//Недопустимое слово: die.
//Результат работы:
//To be, or not to be, that is the question,
//Whether 'tis nobler in the mind to suffer
//The slings and arrows of outrageous fortune, Or to take arms against a sea of troubles,
//And by opposing end them? To ***: to sleep;
//No more; and by a sleep to say we end
//The heart-ache and the thousand natural shocks
//That flesh is heir to, 'tis a consummation
//Devoutly to be wish'd. To ***, to sleep.
//Статистика: 2 замены слова die.
using System;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        Console.WriteLine("Введите текст:");
        string text = Console.ReadLine();

        Console.Write("Запрещённое слово: ");
        string bad = Console.ReadLine();

        int count = 0;
        string star = new string('*', bad.Length);

        string result = Regex.Replace(
            text,
            bad,
            m => { count++; return star; },
            RegexOptions.IgnoreCase
        );

        Console.WriteLine("\nРезультат:");
        Console.WriteLine(result);
        Console.WriteLine($"\nСтатистика: {count} замены слова \"{bad}\".");
    }
}
