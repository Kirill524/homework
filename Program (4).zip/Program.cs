﻿//Задание 1
//Создайте приложение, которое отображает количество
//чётных, нечётных, уникальных элементов массива.

using System;
using System.Linq;

class Program
{
    static void Main()
    {
        int[] arr = { 1, 2, 3, 2, 4, 5, 5, 6, 7 };

        int evenCount = arr.Count(x => x % 2 == 0);
        int oddCount = arr.Count(x => x % 2 != 0);
        int uniqueCount = arr.Distinct().Count();

        Console.WriteLine("Массив: " + string.Join(", ", arr));
        Console.WriteLine($"Чётные элементы: {evenCount}");
        Console.WriteLine($"Нечётные элементы: {oddCount}");
        Console.WriteLine($"Уникальные элементы: {uniqueCount}");
    }
}

//Задание 2
//Создайте приложение, отображающее количество
//значений в массиве меньше заданного параметра пользователем. Например, количество значений меньших, чем 7
//(7 введено пользователем с клавиатуры).

using System;

class Program
{
    static void Main()
    {
        int[] arr = { 3, 7, 1, 9, 5, 6, 2, 8 };
        Console.Write("Введите число для сравнения: ");
        int limit = int.Parse(Console.ReadLine());

        int count = 0;
        foreach (int x in arr)
            if (x < limit) count++;

        Console.WriteLine($"Количество элементов меньше {limit}: {count}");
    }
}

//Задание 3
//Пользователь вводит с клавиатуры три числа. Необходимо подсчитать сколько раз последовательность из этих
//трёх чисел встречается в массиве.
//Например:
//пользователь ввёл: 7 6 5;
//массив: 7 6 5 3 4 7 6 5 8 7 6 5;
//количество повторений последовательности: 3.

using System;

class Program
{
    static void Main()
    {
        int[] arr = { 7, 6, 5, 3, 4, 7, 6, 5, 8, 7, 6, 5 };

        Console.WriteLine("Введите три числа через пробел:");
        string[] input = Console.ReadLine().Split();
        int a = int.Parse(input[0]);
        int b = int.Parse(input[1]);
        int c = int.Parse(input[2]);

        int count = 0;
        for (int i = 0; i <= arr.Length - 3; i++)
        {
            if (arr[i] == a && arr[i + 1] == b && arr[i + 2] == c)
                count++;
        }

        Console.WriteLine($"Последовательность встречается {count} раз(а).");
    }
}

//Задание 4
//Даны 2 массива размерности M и N соответственно.
//Необходимо переписать в третий массив общие элементы первых двух массивов без повторений.

using System;
using System.Linq;

class Program
{
    static void Main()
    {
        int[] A = { 1, 2, 3, 4, 5 };
        int[] B = { 3, 4, 5, 6, 7 };

        int[] common = A.Intersect(B).Distinct().ToArray();

        Console.WriteLine("Общие элементы: " + string.Join(", ", common));
    }
}

//Задание 5
//Разработайте приложение, которое будет находить минимальное и максимальное значение в двумерном массиве.

using System;

class Program
{
    static void Main()
    {
        int[,] arr = {
            { 5, 3, 7 },
            { 2, 8, 1 },
            { 4, 6, 9 }
        };

        int min = arr[0, 0];
        int max = arr[0, 0];

        for (int i = 0; i < arr.GetLength(0); i++)
            for (int j = 0; j < arr.GetLength(1); j++)
            {
                if (arr[i, j] < min) min = arr[i, j];
                if (arr[i, j] > max) max = arr[i, j];
            }

        Console.WriteLine("Минимум: " + min);
        Console.WriteLine("Максимум: " + max);
    }
}

//Задание 6
//Пользователь вводит предложение с клавиатуры. Вам
//необходимо подсчитать количество слов в нём.

using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите предложение: ");
        string s = Console.ReadLine();

        string[] words = s.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);

        Console.WriteLine("Количество слов: " + words.Length);
    }
}

//Задание 7
//Пользователь вводит предложение с клавиатуры. Вам
//необходимо перевернуть каждое слово предложения и
//отобразить результат на экран.
//Например:
//пользователь ввёл: sun cat dogs cup tea;
//после переворота: nus tac sgod puc aet.

using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите предложение: ");
        string s = Console.ReadLine();

        string[] words = s.Split(' ');
        for (int i = 0; i < words.Length; i++)
        {
            char[] chars = words[i].ToCharArray();
            Array.Reverse(chars);
            words[i] = new string(chars);
        }

        string result = string.Join(" ", words);
        Console.WriteLine("После переворота: " + result);
    }
}

//Задание 8
//Пользователь вводит с клавиатуры предложение. Приложение должно посчитать количество гласных букв в нём.

using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите предложение: ");
        string s = Console.ReadLine().ToLower();

        string vowels = "aeiouаеёиоуыэюя";
        int count = 0;

        foreach (char c in s)
            if (vowels.Contains(c))
                count++;

        Console.WriteLine("Количество гласных букв: " + count);
    }
}

//Задание 9
//Реализуйте приложение для подсчёта количество вхождений подстроки в строку. Пользователь вводит исходную
//строку и слово для поиска. Приложений отображает результат поиска.
//Например:
//пользователь ввёл: Why she had to go. I don't know, she
//wouldn't say;
//подстрока для поиска: she;
//результат поиска: 2.
using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите исходную строку: ");
        string text = Console.ReadLine();

        Console.Write("Введите подстроку для поиска: ");
        string sub = Console.ReadLine();

        int count = 0;
        int index = 0;

        while ((index = text.IndexOf(sub, index, StringComparison.OrdinalIgnoreCase)) != -1)
        {
            count++;
            index += sub.Length;
        }

        Console.WriteLine($"Количество вхождений: {count}");
    }
}
