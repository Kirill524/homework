﻿//Задание 1
//Выведите на экран цитату Бьярна Страуструпа: It's easy
//to win forgiveness for being wrong; being right is what gets you
//into real trouble.
//Пример вывода:
//It's easy to win forgiveness for being wrong;
//being right is what gets you into real trouble.
//Bjarne Stroustrup

using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("It's easy to win forgiveness for being wrong;");
        Console.WriteLine("being right is what gets you into real trouble.");
        Console.WriteLine("Bjarne Stroustrup");
    }
}

//Задание 2
//Пользователь вводит с клавиатуры пять чисел. Необходимо найти сумму чисел, максимум и минимум из
//пяти чисел, произведение чисел. Результат вычислений
//вывести на экран.

using System;
using System.Linq;

class Program
{
    static void Main()
    {
        int[] nums = new int[5];

        for (int i = 0; i < 5; i++)
        {
            Console.Write("Введите число: ");
            nums[i] = int.Parse(Console.ReadLine());
        }

        int sum = nums.Sum();
        int product = nums.Aggregate(1, (a, b) => a * b);
        int max = nums.Max();
        int min = nums.Min();

        Console.WriteLine($"Сумма: {sum}");
        Console.WriteLine($"Произведение: {product}");
        Console.WriteLine($"Максимум: {max}");
        Console.WriteLine($"Минимум: {min}");
    }
}

//Задание 3
//Пользователь с клавиатуры вводит шестизначное число.
//Необходимо перевернуть число и отобразить результат.
//Например, если введено 341256, результат 652143.

using System;
using System.Linq;

class Program
{
    static void Main()
    {
        Console.Write("Введите шестизначное число: ");
        string s = Console.ReadLine();

        string reversed = new string(s.Reverse().ToArray());

        Console.WriteLine($"Результат: {reversed}");
    }
}

//Задание 4
//Пользователь вводит с клавиатуры границы числового
//диапазона. Требуется показать все числа Фибоначчи из
//этого диапазона. Числа Фибоначчи — элементы числовой
//последовательности, в которой первые два числа равны 0
//и 1, а каждое последующее число равно сумме двух предыдущих чисел. Например, если указан диапазон 0–20,
//результат будет: 0, 1, 1, 2, 3, 5, 8, 13.

using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите нижнюю границу: ");
        int a = int.Parse(Console.ReadLine());

        Console.Write("Введите верхнюю границу: ");
        int b = int.Parse(Console.ReadLine());

        int f1 = 0;
        int f2 = 1;

        Console.Write("Числа Фибоначчи: ");

        while (f1 <= b)
        {
            if (f1 >= a)
                Console.Write(f1 + " ");

            int next = f1 + f2;
            f1 = f2;
            f2 = next;
        }
    }
}

//Задание 5
//Даны целые положительные числа A и B (A < B). Вывести все целые числа от A до B включительно; каждое
//число должно выводиться на новой строке; при этом каждое число должно выводиться количество раз, равное
//его значению. Например: если А = 3, а В = 7, то программа
//должна сформировать в консоли следующий вывод:
//3 3 3
//4 4 4 4
//5 5 5 5 5
//6 6 6 6 6 6
//7 7 7 7 7 7 7.

using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите A: ");
        int A = int.Parse(Console.ReadLine());

        Console.Write("Введите B: ");
        int B = int.Parse(Console.ReadLine());

        for (int i = A; i <= B; i++)
        {
            for (int j = 0; j < i; j++)
                Console.Write(i + " ");

            Console.WriteLine();
        }
    }
}

//Задание 6
//Пользователь с клавиатуры вводит длину линии, символ заполнитель, направление линии (горизонтальная,
//вертикальная). Программа отображает линию по заданным
//параметрам. Например: +++++.
//Параметры линии: горизонтальная линия, длина равна
//пяти, символ заполнитель +.
using System;

class Program
{
    static void Main()
    {
        Console.Write("Длина линии: ");
        int length = int.Parse(Console.ReadLine());

        Console.Write("Символ заполнения: ");
        char ch = Console.ReadKey().KeyChar;
        Console.WriteLine();

        Console.Write("Направление (h - горизонтальная, v - вертикальная): ");
        char dir = Console.ReadKey().KeyChar;
        Console.WriteLine();

        if (dir == 'h')
        {
            for (int i = 0; i < length; i++)
                Console.Write(ch);
        }
        else if (dir == 'v')
        {
            for (int i = 0; i < length; i++)
                Console.WriteLine(ch);
        }
        else
        {
            Console.WriteLine("Неизвестное направление!");
        }
    }
}