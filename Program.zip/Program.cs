﻿//Задание 1.
//Пользователь вводит с клавиатуры число в диапазоне от 1 до 100. Если число кратно 3 (делится на 3 без остатка) нужно вывести слово Fizz.
//Если число кратно 5 нужно вывести слово Buzz. Если число кратно 3 и 5 нужно вывести Fizz Buzz. Если число не кратно не 3 и 5 нужно вывести само число.
//Если пользователь ввел значение не в диапазоне от 1 до 100 требуется вывести сообщение об ошибке.

using System;
using System.Globalization;

class Program
{
    static void Main()
    {
        Console.Write("Введите число от 1 до 100: ");
        int number = int.Parse(Console.ReadLine());

        if (number < 1 || number > 100)
        {
            Console.WriteLine("Ошибка: число должно быть в диапазоне от 1 до 100.");
        }
        else if (number % 3 == 0 && number % 5 == 0)
        {
            Console.WriteLine("Fizz Buzz");
        }
        else if (number % 3 == 0)
        {
            Console.WriteLine("Fizz");
        }
        else if (number % 5 == 0)
        {
            Console.WriteLine("Buzz");
        }
        else
        {
            Console.WriteLine(number);
        }
    }
}

//Задание 2.
//Пользователь вводит с клавиатуры два числа. Первое число — это значение, второе число процент, который необходимо посчитать. 
//Например, мы ввели с клавиатуры 90 и 10. Требуется вывести на экран 10 процентов от 90. Результат: 9.

using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите число: ");
        double value = double.Parse(Console.ReadLine());

        Console.Write("Введите процкнт: ");
        double percent = double.Parse(Console.ReadLine());

        double result = value * percent / 100;

        Console.WriteLine($"{percent}% от {value} = {result}");
    }
}

//Задание 3.
//Пользователь вводит с клавиатуры четыре цифры. Необходимо создать число, содержащее эти цифры. 
//Например, если с клавиатуры введено 1, 5, 7, 8 тогда нужно сформировать число 1578.

using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите первую циыру: ");
        int a = int.Parse(Console.ReadLine());

        Console.Write("Введите вторую цифру: ");
        int b = int.Parse(Console.ReadLine());

        Console.Write("Введите третью цифру: ");
        int c = int.Parse(Console.ReadLine());

        Console.Write("Введите четвертую цифру: ");
        int d = int.Parse(Console.ReadLine());

        int number = a * 1000 + b * 100 + c * 10 + d;

        Console.WriteLine($"Полученное число: {number}");
    }
}

//Задание 4
//Пользователь вводит шестизначное число. После чего
//пользователь вводит номера разрядов для обмена цифр.
//Например, если пользователь ввёл один и шесть — это
//значит, что надо обменять местами первую и шестую
//цифры.
//Число 723895 должно превратиться в 523897.
//Если пользователь ввел не шестизначное число требуется вывести сообщение об ошибке.

using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите шестизначное число: ");
        string number = Console.ReadLine();

        if (number.Length != 6 || !int.TryParse(number, out _))
        {
            Console.WriteLine("Ошибка: нужно ввести шестизначное число.");
            return;
        }

        Console.Write("Введите первый номер разряда (от 1 до 6): ");
        int pos1 = int.Parse(Console.ReadLine());

        Console.Write("Введите второй номер разряда (от 1 до 6): ");
        int pos2 = int.Parse(Console.ReadLine());

        if (pos1 < 1 || pos1 > 6 || pos2 < 1 || pos2 > 6)
        {
            Console.WriteLine("Ошибка: номера разрядов должны быть от 1 до 6.");
            return;
        }

        char[] digits = number.ToCharArray();

        char temp = digits[pos1 - 1];
        digits[pos1 - 1] = digits[pos2 - 1];
        digits[pos2 - 1] = temp;

        Console.WriteLine($"Результат: {new string(digits)}");
    }
}

//Задание 5
//Пользователь вводит с клавиатуры дату. Приложение должно отобразить название сезона и дня недели.
//Например, если введено 22.12.2021, приложение должно
//отобразить Winter Wednesday.

using System;
using System.Globalization;

class Program
{
    static void Main()
    {
        Console.Write("Введите дату (в формате dd.MM.yyyy): ");
        string input = Console.ReadLine();

        if (DateTime.TryParseExact(input, "dd.MM.yyyy", null, DateTimeStyles.None, out DateTime date))
        {
            string season;

            int month = date.Month;
            if (month == 12 || month == 1 || month == 2) season = "Winter";
            else if (month >= 3 && month <= 5) season = "Spring";
            else if (month >= 6 && month <= 8) season = "Summer";
            else season = "Autumn";

            string dayOfWeek = date.ToString("dddd", new CultureInfo("en-US"));

            dayOfWeek = char.ToUpper(dayOfWeek[0]) + dayOfWeek.Substring(1);

            Console.WriteLine($"{season} {dayOfWeek}");
        }
        else
        {
            Console.WriteLine("Ошибка: неверный формат даты.");
        }
    }
}

//Задание 6
//Пользователь вводит с клавиатуры показания температуры. В зависимости от выбора пользователя программа переводит температуру из Фаренгейта в Цельсий
//или наоборот.

using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите температуру: ");
        double temp = double.Parse(Console.ReadLine());

        Console.WriteLine("Выберите перевод:");
        Console.WriteLine("1 — из Фаренгейта в Цельсий");
        Console.WriteLine("2 — из Цельсия в Фаренгейт");
        int choice = int.Parse(Console.ReadLine());

        if (choice == 1)
        {
            double celsius = (temp - 32) * 5 / 9;
            Console.WriteLine($"Температура в Цельсиях: {celsius:F2}");
        }
        else if (choice == 2)
        {
            double fahrenheit = temp * 9 / 5 + 32;
            Console.WriteLine($"Температура в Фаренгейтах: {fahrenheit:F2}");
        }
        else
        {
            Console.WriteLine("Ошибка: выберите 1 или 2.");
        }
    }
}

//Задание 7
//Пользователь вводит с клавиатуры два числа. Нужно
//показать все четные числа в указанном диапазоне. Если
//границы диапазона указаны неправильно требуется произвести нормализацию границ. Например, пользователь
//ввел 20 и 11, требуется нормализация, после которой
//начало диапазона станет равно 11, а конец 20.
using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите первое число: ");
        int a = int.Parse(Console.ReadLine());

        Console.Write("Введите второе число: ");
        int b = int.Parse(Console.ReadLine());

        if (a > b)
        {
            int temp = a;
            a = b;
            b = temp;
        }

        Console.WriteLine($"Чётные числа в диапазоне от {a} до {b}:");

        for (int i = a; i <= b; i++)
        {
            if (i % 2 == 0)
                Console.Write(i + " ");
        }

        Console.WriteLine();
    }
}